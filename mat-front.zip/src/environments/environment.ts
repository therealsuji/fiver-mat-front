// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  config: {
    apiKey: "AIzaSyAPxEy2LHBitpV5rjp9WsezkRqrNWcRaTQ",
    authDomain: "afffmf-d0100.firebaseapp.com",
    databaseURL: "https://afffmf-d0100.firebaseio.com",
    projectId: "afffmf-d0100",
    storageBucket: "afffmf-d0100.appspot.com",
    messagingSenderId: "671712243417",
    appId: "1:671712243417:web:ae294350f53b89ae8398c8",
    measurementId: "G-SBWMWCZCJ7"
  }

};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
